# main.sh
##赋予可执行权限
chmod +x log.sh
chmod +x livetv
chmod +x youtube
chmod +x easy-cron

##Easy-cron启动
# 更改Easy-cron工作目录
ecpath=$(pwd|cut -d \/ -f4)
ecconfpath=$(cat config.yaml|grep /home/runner|head -n 1)
ecconfpath=${ecconfpath#*home\/runner\/}
ecconfpath=${ecconfpath%%\/*}
sed -i "s/$ecconfpath/$ecpath/g" config.yaml
# 启动Easy-cron
./easy-cron >/dev/null 2>&1 &

##LiveTV启动
#获取工作路径
home=$(pwd)
#启动程序
./livetv -DIR $home -PORT 9001
