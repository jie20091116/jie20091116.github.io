#!/bin/bash
home=$(pwd)
echo -n '' >$home/livetv.log
rm $home/easy-cron-log